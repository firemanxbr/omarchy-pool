# bash completion for hey                                  -*- shell-script -*-

__hey_debug()
{
    if [[ -n ${BASH_COMP_DEBUG_FILE:-} ]]; then
        echo "$*" >> "${BASH_COMP_DEBUG_FILE}"
    fi
}

# Homebrew on Macs have version 1.3 of bash-completion which doesn't include
# _init_completion. This is a very minimal version of that function.
__hey_init_completion()
{
    COMPREPLY=()
    _get_comp_words_by_ref "$@" cur prev words cword
}

__hey_index_of_word()
{
    local w word=$1
    shift
    index=0
    for w in "$@"; do
        [[ $w = "$word" ]] && return
        index=$((index+1))
    done
    index=-1
}

__hey_contains_word()
{
    local w word=$1; shift
    for w in "$@"; do
        [[ $w = "$word" ]] && return
    done
    return 1
}

__hey_handle_go_custom_completion()
{
    __hey_debug "${FUNCNAME[0]}: cur is ${cur}, words[*] is ${words[*]}, #words[@] is ${#words[@]}"

    local shellCompDirectiveError=1
    local shellCompDirectiveNoSpace=2
    local shellCompDirectiveNoFileComp=4
    local shellCompDirectiveFilterFileExt=8
    local shellCompDirectiveFilterDirs=16

    local out requestComp lastParam lastChar comp directive args

    # Prepare the command to request completions for the program.
    # Calling ${words[0]} instead of directly hey allows handling aliases
    args=("${words[@]:1}")
    # Disable ActiveHelp which is not supported for bash completion v1
    requestComp="HEY_ACTIVE_HELP=0 ${words[0]} __completeNoDesc ${args[*]}"

    lastParam=${words[$((${#words[@]}-1))]}
    lastChar=${lastParam:$((${#lastParam}-1)):1}
    __hey_debug "${FUNCNAME[0]}: lastParam ${lastParam}, lastChar ${lastChar}"

    if [ -z "${cur}" ] && [ "${lastChar}" != "=" ]; then
        # If the last parameter is complete (there is a space following it)
        # We add an extra empty parameter so we can indicate this to the go method.
        __hey_debug "${FUNCNAME[0]}: Adding extra empty parameter"
        requestComp="${requestComp} \"\""
    fi

    __hey_debug "${FUNCNAME[0]}: calling ${requestComp}"
    # Use eval to handle any environment variables and such
    out=$(eval "${requestComp}" 2>/dev/null)

    # Extract the directive integer at the very end of the output following a colon (:)
    directive=${out##*:}
    # Remove the directive
    out=${out%:*}
    if [ "${directive}" = "${out}" ]; then
        # There is not directive specified
        directive=0
    fi
    __hey_debug "${FUNCNAME[0]}: the completion directive is: ${directive}"
    __hey_debug "${FUNCNAME[0]}: the completions are: ${out}"

    if [ $((directive & shellCompDirectiveError)) -ne 0 ]; then
        # Error code.  No completion.
        __hey_debug "${FUNCNAME[0]}: received error from custom completion go code"
        return
    else
        if [ $((directive & shellCompDirectiveNoSpace)) -ne 0 ]; then
            if [[ $(type -t compopt) = "builtin" ]]; then
                __hey_debug "${FUNCNAME[0]}: activating no space"
                compopt -o nospace
            fi
        fi
        if [ $((directive & shellCompDirectiveNoFileComp)) -ne 0 ]; then
            if [[ $(type -t compopt) = "builtin" ]]; then
                __hey_debug "${FUNCNAME[0]}: activating no file completion"
                compopt +o default
            fi
        fi
    fi

    if [ $((directive & shellCompDirectiveFilterFileExt)) -ne 0 ]; then
        # File extension filtering
        local fullFilter filter filteringCmd
        # Do not use quotes around the $out variable or else newline
        # characters will be kept.
        for filter in ${out}; do
            fullFilter+="$filter|"
        done

        filteringCmd="_filedir $fullFilter"
        __hey_debug "File filtering command: $filteringCmd"
        $filteringCmd
    elif [ $((directive & shellCompDirectiveFilterDirs)) -ne 0 ]; then
        # File completion for directories only
        local subdir
        # Use printf to strip any trailing newline
        subdir=$(printf "%s" "${out}")
        if [ -n "$subdir" ]; then
            __hey_debug "Listing directories in $subdir"
            __hey_handle_subdirs_in_dir_flag "$subdir"
        else
            __hey_debug "Listing directories in ."
            _filedir -d
        fi
    else
        while IFS='' read -r comp; do
            COMPREPLY+=("$comp")
        done < <(compgen -W "${out}" -- "$cur")
    fi
}

__hey_handle_reply()
{
    __hey_debug "${FUNCNAME[0]}"
    local comp
    case $cur in
        -*)
            if [[ $(type -t compopt) = "builtin" ]]; then
                compopt -o nospace
            fi
            local allflags
            if [ ${#must_have_one_flag[@]} -ne 0 ]; then
                allflags=("${must_have_one_flag[@]}")
            else
                allflags=("${flags[*]} ${two_word_flags[*]}")
            fi
            while IFS='' read -r comp; do
                COMPREPLY+=("$comp")
            done < <(compgen -W "${allflags[*]}" -- "$cur")
            if [[ $(type -t compopt) = "builtin" ]]; then
                [[ "${COMPREPLY[0]}" == *= ]] || compopt +o nospace
            fi

            # complete after --flag=abc
            if [[ $cur == *=* ]]; then
                if [[ $(type -t compopt) = "builtin" ]]; then
                    compopt +o nospace
                fi

                local index flag
                flag="${cur%=*}"
                __hey_index_of_word "${flag}" "${flags_with_completion[@]}"
                COMPREPLY=()
                if [[ ${index} -ge 0 ]]; then
                    PREFIX=""
                    cur="${cur#*=}"
                    ${flags_completion[${index}]}
                    if [ -n "${ZSH_VERSION:-}" ]; then
                        # zsh completion needs --flag= prefix
                        eval "COMPREPLY=( \"\${COMPREPLY[@]/#/${flag}=}\" )"
                    fi
                fi
            fi

            if [[ -z "${flag_parsing_disabled}" ]]; then
                # If flag parsing is enabled, we have completed the flags and can return.
                # If flag parsing is disabled, we may not know all (or any) of the flags, so we fallthrough
                # to possibly call handle_go_custom_completion.
                return 0;
            fi
            ;;
    esac

    # check if we are handling a flag with special work handling
    local index
    __hey_index_of_word "${prev}" "${flags_with_completion[@]}"
    if [[ ${index} -ge 0 ]]; then
        ${flags_completion[${index}]}
        return
    fi

    # we are parsing a flag and don't have a special handler, no completion
    if [[ ${cur} != "${words[cword]}" ]]; then
        return
    fi

    local completions
    completions=("${commands[@]}")
    if [[ ${#must_have_one_noun[@]} -ne 0 ]]; then
        completions+=("${must_have_one_noun[@]}")
    elif [[ -n "${has_completion_function}" ]]; then
        # if a go completion function is provided, defer to that function
        __hey_handle_go_custom_completion
    fi
    if [[ ${#must_have_one_flag[@]} -ne 0 ]]; then
        completions+=("${must_have_one_flag[@]}")
    fi
    while IFS='' read -r comp; do
        COMPREPLY+=("$comp")
    done < <(compgen -W "${completions[*]}" -- "$cur")

    if [[ ${#COMPREPLY[@]} -eq 0 && ${#noun_aliases[@]} -gt 0 && ${#must_have_one_noun[@]} -ne 0 ]]; then
        while IFS='' read -r comp; do
            COMPREPLY+=("$comp")
        done < <(compgen -W "${noun_aliases[*]}" -- "$cur")
    fi

    if [[ ${#COMPREPLY[@]} -eq 0 ]]; then
        if declare -F __hey_custom_func >/dev/null; then
            # try command name qualified custom func
            __hey_custom_func
        else
            # otherwise fall back to unqualified for compatibility
            declare -F __custom_func >/dev/null && __custom_func
        fi
    fi

    # available in bash-completion >= 2, not always present on macOS
    if declare -F __ltrim_colon_completions >/dev/null; then
        __ltrim_colon_completions "$cur"
    fi

    # If there is only 1 completion and it is a flag with an = it will be completed
    # but we don't want a space after the =
    if [[ "${#COMPREPLY[@]}" -eq "1" ]] && [[ $(type -t compopt) = "builtin" ]] && [[ "${COMPREPLY[0]}" == --*= ]]; then
       compopt -o nospace
    fi
}

# The arguments should be in the form "ext1|ext2|extn"
__hey_handle_filename_extension_flag()
{
    local ext="$1"
    _filedir "@(${ext})"
}

__hey_handle_subdirs_in_dir_flag()
{
    local dir="$1"
    pushd "${dir}" >/dev/null 2>&1 && _filedir -d && popd >/dev/null 2>&1 || return
}

__hey_handle_flag()
{
    __hey_debug "${FUNCNAME[0]}: c is $c words[c] is ${words[c]}"

    # if a command required a flag, and we found it, unset must_have_one_flag()
    local flagname=${words[c]}
    local flagvalue=""
    # if the word contained an =
    if [[ ${words[c]} == *"="* ]]; then
        flagvalue=${flagname#*=} # take in as flagvalue after the =
        flagname=${flagname%=*} # strip everything after the =
        flagname="${flagname}=" # but put the = back
    fi
    __hey_debug "${FUNCNAME[0]}: looking for ${flagname}"
    if __hey_contains_word "${flagname}" "${must_have_one_flag[@]}"; then
        must_have_one_flag=()
    fi

    # if you set a flag which only applies to this command, don't show subcommands
    if __hey_contains_word "${flagname}" "${local_nonpersistent_flags[@]}"; then
      commands=()
    fi

    # keep flag value with flagname as flaghash
    # flaghash variable is an associative array which is only supported in bash > 3.
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        if [ -n "${flagvalue}" ] ; then
            flaghash[${flagname}]=${flagvalue}
        elif [ -n "${words[ $((c+1)) ]}" ] ; then
            flaghash[${flagname}]=${words[ $((c+1)) ]}
        else
            flaghash[${flagname}]="true" # pad "true" for bool flag
        fi
    fi

    # skip the argument to a two word flag
    if [[ ${words[c]} != *"="* ]] && __hey_contains_word "${words[c]}" "${two_word_flags[@]}"; then
        __hey_debug "${FUNCNAME[0]}: found a flag ${words[c]}, skip the next argument"
        c=$((c+1))
        # if we are looking for a flags value, don't show commands
        if [[ $c -eq $cword ]]; then
            commands=()
        fi
    fi

    c=$((c+1))

}

__hey_handle_noun()
{
    __hey_debug "${FUNCNAME[0]}: c is $c words[c] is ${words[c]}"

    if __hey_contains_word "${words[c]}" "${must_have_one_noun[@]}"; then
        must_have_one_noun=()
    elif __hey_contains_word "${words[c]}" "${noun_aliases[@]}"; then
        must_have_one_noun=()
    fi

    nouns+=("${words[c]}")
    c=$((c+1))
}

__hey_handle_command()
{
    __hey_debug "${FUNCNAME[0]}: c is $c words[c] is ${words[c]}"

    local next_command
    if [[ -n ${last_command} ]]; then
        next_command="_${last_command}_${words[c]//:/__}"
    else
        if [[ $c -eq 0 ]]; then
            next_command="_hey_root_command"
        else
            next_command="_${words[c]//:/__}"
        fi
    fi
    c=$((c+1))
    __hey_debug "${FUNCNAME[0]}: looking for ${next_command}"
    declare -F "$next_command" >/dev/null && $next_command
}

__hey_handle_word()
{
    if [[ $c -ge $cword ]]; then
        __hey_handle_reply
        return
    fi
    __hey_debug "${FUNCNAME[0]}: c is $c words[c] is ${words[c]}"
    if [[ "${words[c]}" == -* ]]; then
        __hey_handle_flag
    elif __hey_contains_word "${words[c]}" "${commands[@]}"; then
        __hey_handle_command
    elif [[ $c -eq 0 ]]; then
        __hey_handle_command
    elif __hey_contains_word "${words[c]}" "${command_aliases[@]}"; then
        # aliashash variable is an associative array which is only supported in bash > 3.
        if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
            words[c]=${aliashash[${words[c]}]}
            __hey_handle_command
        else
            __hey_handle_noun
        fi
    else
        __hey_handle_noun
    fi
    __hey_handle_word
}

_hey_account_list()
{
    last_command="hey_account_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_account_use()
{
    last_command="hey_account_use"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_account()
{
    last_command="hey_account"

    command_aliases=()

    commands=()
    commands+=("list")
    commands+=("use")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_attachment_list()
{
    last_command="hey_attachment_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--allow-partial")
    local_nonpersistent_flags+=("--allow-partial")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_attachment_save()
{
    last_command="hey_attachment_save"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--force")
    local_nonpersistent_flags+=("--force")
    flags+=("--output=")
    two_word_flags+=("--output")
    two_word_flags+=("-o")
    local_nonpersistent_flags+=("--output")
    local_nonpersistent_flags+=("--output=")
    local_nonpersistent_flags+=("-o")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_attachment()
{
    last_command="hey_attachment"

    command_aliases=()

    commands=()
    commands+=("list")
    commands+=("save")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_auth_login()
{
    last_command="hey_auth_login"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--cookie=")
    two_word_flags+=("--cookie")
    local_nonpersistent_flags+=("--cookie")
    local_nonpersistent_flags+=("--cookie=")
    flags+=("--no-browser")
    local_nonpersistent_flags+=("--no-browser")
    flags+=("--token=")
    two_word_flags+=("--token")
    local_nonpersistent_flags+=("--token")
    local_nonpersistent_flags+=("--token=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_auth_logout()
{
    last_command="hey_auth_logout"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_auth_refresh()
{
    last_command="hey_auth_refresh"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_auth_status()
{
    last_command="hey_auth_status"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_auth_token()
{
    last_command="hey_auth_token"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--stored")
    local_nonpersistent_flags+=("--stored")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_auth()
{
    last_command="hey_auth"

    command_aliases=()

    commands=()
    commands+=("login")
    commands+=("logout")
    commands+=("refresh")
    commands+=("status")
    commands+=("token")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_box_list()
{
    last_command="hey_box_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_box_view()
{
    last_command="hey_box_view"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_box()
{
    last_command="hey_box"

    command_aliases=()

    commands=()
    commands+=("list")
    commands+=("view")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bubble_list()
{
    last_command="hey_bubble_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bubble_pop()
{
    last_command="hey_bubble_pop"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bubble_up()
{
    last_command="hey_bubble_up"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--next-week")
    local_nonpersistent_flags+=("--next-week")
    flags+=("--now")
    local_nonpersistent_flags+=("--now")
    flags+=("--on=")
    two_word_flags+=("--on")
    local_nonpersistent_flags+=("--on")
    local_nonpersistent_flags+=("--on=")
    flags+=("--tomorrow")
    local_nonpersistent_flags+=("--tomorrow")
    flags+=("--weekend")
    local_nonpersistent_flags+=("--weekend")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bubble()
{
    last_command="hey_bubble"

    command_aliases=()

    commands=()
    commands+=("list")
    commands+=("pop")
    commands+=("up")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bulk-reply_preview()
{
    last_command="hey_bulk-reply_preview"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bulk-reply_send()
{
    last_command="hey_bulk-reply_send"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--attach=")
    two_word_flags+=("--attach")
    local_nonpersistent_flags+=("--attach")
    local_nonpersistent_flags+=("--attach=")
    flags+=("--message=")
    two_word_flags+=("--message")
    two_word_flags+=("-m")
    local_nonpersistent_flags+=("--message")
    local_nonpersistent_flags+=("--message=")
    local_nonpersistent_flags+=("-m")
    flags+=("--message-html=")
    two_word_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bulk-reply_undo()
{
    last_command="hey_bulk-reply_undo"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bulk-reply()
{
    last_command="hey_bulk-reply"

    command_aliases=()

    commands=()
    commands+=("preview")
    commands+=("send")
    commands+=("undo")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bundle_view()
{
    last_command="hey_bundle_view"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_bundle()
{
    last_command="hey_bundle"

    command_aliases=()

    commands=()
    commands+=("view")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_calendar_list()
{
    last_command="hey_calendar_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_calendar()
{
    last_command="hey_calendar"

    command_aliases=()

    commands=()
    commands+=("list")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_clip_create()
{
    last_command="hey_clip_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--content=")
    two_word_flags+=("--content")
    local_nonpersistent_flags+=("--content")
    local_nonpersistent_flags+=("--content=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_clip_delete()
{
    last_command="hey_clip_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_clip_list()
{
    last_command="hey_clip_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_clip()
{
    last_command="hey_clip"

    command_aliases=()

    commands=()
    commands+=("create")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("add")
        aliashash["add"]="create"
    fi
    commands+=("delete")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("remove")
        aliashash["remove"]="delete"
        command_aliases+=("rm")
        aliashash["rm"]="delete"
    fi
    commands+=("list")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_collection_add()
{
    last_command="hey_collection_add"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_collection_create()
{
    last_command="hey_collection_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--summary=")
    two_word_flags+=("--summary")
    local_nonpersistent_flags+=("--summary")
    local_nonpersistent_flags+=("--summary=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_collection_list()
{
    last_command="hey_collection_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_collection_remove()
{
    last_command="hey_collection_remove"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--from=")
    two_word_flags+=("--from")
    local_nonpersistent_flags+=("--from")
    local_nonpersistent_flags+=("--from=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_collection_update()
{
    last_command="hey_collection_update"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--summary=")
    two_word_flags+=("--summary")
    local_nonpersistent_flags+=("--summary")
    local_nonpersistent_flags+=("--summary=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_collection_view()
{
    last_command="hey_collection_view"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_collection()
{
    last_command="hey_collection"

    command_aliases=()

    commands=()
    commands+=("add")
    commands+=("create")
    commands+=("list")
    commands+=("remove")
    commands+=("update")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("edit")
        aliashash["edit"]="update"
    fi
    commands+=("view")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_commands()
{
    last_command="hey_commands"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_compose()
{
    last_command="hey_compose"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--attach=")
    two_word_flags+=("--attach")
    local_nonpersistent_flags+=("--attach")
    local_nonpersistent_flags+=("--attach=")
    flags+=("--bcc=")
    two_word_flags+=("--bcc")
    local_nonpersistent_flags+=("--bcc")
    local_nonpersistent_flags+=("--bcc=")
    flags+=("--cc=")
    two_word_flags+=("--cc")
    local_nonpersistent_flags+=("--cc")
    local_nonpersistent_flags+=("--cc=")
    flags+=("--draft")
    local_nonpersistent_flags+=("--draft")
    flags+=("--message=")
    two_word_flags+=("--message")
    two_word_flags+=("-m")
    local_nonpersistent_flags+=("--message")
    local_nonpersistent_flags+=("--message=")
    local_nonpersistent_flags+=("-m")
    flags+=("--message-html=")
    two_word_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html=")
    flags+=("--no-name-tag")
    local_nonpersistent_flags+=("--no-name-tag")
    flags+=("--subject=")
    two_word_flags+=("--subject")
    local_nonpersistent_flags+=("--subject")
    local_nonpersistent_flags+=("--subject=")
    flags+=("--thread-id=")
    two_word_flags+=("--thread-id")
    local_nonpersistent_flags+=("--thread-id")
    local_nonpersistent_flags+=("--thread-id=")
    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_config_set()
{
    last_command="hey_config_set"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_config_show()
{
    last_command="hey_config_show"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_config_trust-local()
{
    last_command="hey_config_trust-local"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_config_trusted-locals()
{
    last_command="hey_config_trusted-locals"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_config_untrust-local()
{
    last_command="hey_config_untrust-local"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_config()
{
    last_command="hey_config"

    command_aliases=()

    commands=()
    commands+=("set")
    commands+=("show")
    commands+=("trust-local")
    commands+=("trusted-locals")
    commands+=("untrust-local")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_add()
{
    last_command="hey_contact_add"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account-user-id=")
    two_word_flags+=("--account-user-id")
    local_nonpersistent_flags+=("--account-user-id")
    local_nonpersistent_flags+=("--account-user-id=")
    flags+=("--alias=")
    two_word_flags+=("--alias")
    local_nonpersistent_flags+=("--alias")
    local_nonpersistent_flags+=("--alias=")
    flags+=("--email=")
    two_word_flags+=("--email")
    local_nonpersistent_flags+=("--email")
    local_nonpersistent_flags+=("--email=")
    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_bundle()
{
    last_command="hey_contact_bundle"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_hide()
{
    last_command="hey_contact_hide"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_list()
{
    last_command="hey_contact_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_note_delete()
{
    last_command="hey_contact_note_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_note_set()
{
    last_command="hey_contact_note_set"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--note=")
    two_word_flags+=("--note")
    two_word_flags+=("-n")
    local_nonpersistent_flags+=("--note")
    local_nonpersistent_flags+=("--note=")
    local_nonpersistent_flags+=("-n")
    flags+=("--note-html=")
    two_word_flags+=("--note-html")
    local_nonpersistent_flags+=("--note-html")
    local_nonpersistent_flags+=("--note-html=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_note_show()
{
    last_command="hey_contact_note_show"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_note()
{
    last_command="hey_contact_note"

    command_aliases=()

    commands=()
    commands+=("delete")
    commands+=("set")
    commands+=("show")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_show()
{
    last_command="hey_contact_show"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_show-again()
{
    last_command="hey_contact_show-again"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_threads()
{
    last_command="hey_contact_threads"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_unbundle()
{
    last_command="hey_contact_unbundle"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact_update()
{
    last_command="hey_contact_update"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--alias=")
    two_word_flags+=("--alias")
    local_nonpersistent_flags+=("--alias")
    local_nonpersistent_flags+=("--alias=")
    flags+=("--email=")
    two_word_flags+=("--email")
    local_nonpersistent_flags+=("--email")
    local_nonpersistent_flags+=("--email=")
    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_contact()
{
    last_command="hey_contact"

    command_aliases=()

    commands=()
    commands+=("add")
    commands+=("bundle")
    commands+=("hide")
    commands+=("list")
    commands+=("note")
    commands+=("show")
    commands+=("show-again")
    commands+=("threads")
    commands+=("unbundle")
    commands+=("update")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_doctor()
{
    last_command="hey_doctor"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_draft_delete()
{
    last_command="hey_draft_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_draft_edit()
{
    last_command="hey_draft_edit"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--bcc=")
    two_word_flags+=("--bcc")
    local_nonpersistent_flags+=("--bcc")
    local_nonpersistent_flags+=("--bcc=")
    flags+=("--cc=")
    two_word_flags+=("--cc")
    local_nonpersistent_flags+=("--cc")
    local_nonpersistent_flags+=("--cc=")
    flags+=("--message=")
    two_word_flags+=("--message")
    two_word_flags+=("-m")
    local_nonpersistent_flags+=("--message")
    local_nonpersistent_flags+=("--message=")
    local_nonpersistent_flags+=("-m")
    flags+=("--message-html=")
    two_word_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html=")
    flags+=("--subject=")
    two_word_flags+=("--subject")
    local_nonpersistent_flags+=("--subject")
    local_nonpersistent_flags+=("--subject=")
    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_draft_list()
{
    last_command="hey_draft_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_draft_send()
{
    last_command="hey_draft_send"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_draft_show()
{
    last_command="hey_draft_show"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_draft()
{
    last_command="hey_draft"

    command_aliases=()

    commands=()
    commands+=("delete")
    commands+=("edit")
    commands+=("list")
    commands+=("send")
    commands+=("show")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_event_add()
{
    last_command="hey_event_add"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all-day")
    local_nonpersistent_flags+=("--all-day")
    flags+=("--calendar=")
    two_word_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar=")
    flags+=("--circle")
    local_nonpersistent_flags+=("--circle")
    flags+=("--countdown=")
    two_word_flags+=("--countdown")
    local_nonpersistent_flags+=("--countdown")
    local_nonpersistent_flags+=("--countdown=")
    flags+=("--countdown-unit=")
    two_word_flags+=("--countdown-unit")
    local_nonpersistent_flags+=("--countdown-unit")
    local_nonpersistent_flags+=("--countdown-unit=")
    flags+=("--end-time=")
    two_word_flags+=("--end-time")
    local_nonpersistent_flags+=("--end-time")
    local_nonpersistent_flags+=("--end-time=")
    flags+=("--ends-on=")
    two_word_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on=")
    flags+=("--invite=")
    two_word_flags+=("--invite")
    local_nonpersistent_flags+=("--invite")
    local_nonpersistent_flags+=("--invite=")
    flags+=("--link=")
    two_word_flags+=("--link")
    local_nonpersistent_flags+=("--link")
    local_nonpersistent_flags+=("--link=")
    flags+=("--location=")
    two_word_flags+=("--location")
    local_nonpersistent_flags+=("--location")
    local_nonpersistent_flags+=("--location=")
    flags+=("--notes=")
    two_word_flags+=("--notes")
    local_nonpersistent_flags+=("--notes")
    local_nonpersistent_flags+=("--notes=")
    flags+=("--remind=")
    two_word_flags+=("--remind")
    local_nonpersistent_flags+=("--remind")
    local_nonpersistent_flags+=("--remind=")
    flags+=("--repeat=")
    two_word_flags+=("--repeat")
    local_nonpersistent_flags+=("--repeat")
    local_nonpersistent_flags+=("--repeat=")
    flags+=("--repeat-times=")
    two_word_flags+=("--repeat-times")
    local_nonpersistent_flags+=("--repeat-times")
    local_nonpersistent_flags+=("--repeat-times=")
    flags+=("--repeat-until=")
    two_word_flags+=("--repeat-until")
    local_nonpersistent_flags+=("--repeat-until")
    local_nonpersistent_flags+=("--repeat-until=")
    flags+=("--start-time=")
    two_word_flags+=("--start-time")
    local_nonpersistent_flags+=("--start-time")
    local_nonpersistent_flags+=("--start-time=")
    flags+=("--starts-on=")
    two_word_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on=")
    flags+=("--time-zone=")
    two_word_flags+=("--time-zone")
    local_nonpersistent_flags+=("--time-zone")
    local_nonpersistent_flags+=("--time-zone=")
    flags+=("--title=")
    two_word_flags+=("--title")
    two_word_flags+=("-t")
    local_nonpersistent_flags+=("--title")
    local_nonpersistent_flags+=("--title=")
    local_nonpersistent_flags+=("-t")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_event_day()
{
    last_command="hey_event_day"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_event_delete()
{
    last_command="hey_event_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_event_edit()
{
    last_command="hey_event_edit"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all-day")
    local_nonpersistent_flags+=("--all-day")
    flags+=("--calendar=")
    two_word_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar=")
    flags+=("--circle")
    local_nonpersistent_flags+=("--circle")
    flags+=("--countdown=")
    two_word_flags+=("--countdown")
    local_nonpersistent_flags+=("--countdown")
    local_nonpersistent_flags+=("--countdown=")
    flags+=("--countdown-unit=")
    two_word_flags+=("--countdown-unit")
    local_nonpersistent_flags+=("--countdown-unit")
    local_nonpersistent_flags+=("--countdown-unit=")
    flags+=("--end-time=")
    two_word_flags+=("--end-time")
    local_nonpersistent_flags+=("--end-time")
    local_nonpersistent_flags+=("--end-time=")
    flags+=("--ends-on=")
    two_word_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on=")
    flags+=("--invite=")
    two_word_flags+=("--invite")
    local_nonpersistent_flags+=("--invite")
    local_nonpersistent_flags+=("--invite=")
    flags+=("--link=")
    two_word_flags+=("--link")
    local_nonpersistent_flags+=("--link")
    local_nonpersistent_flags+=("--link=")
    flags+=("--location=")
    two_word_flags+=("--location")
    local_nonpersistent_flags+=("--location")
    local_nonpersistent_flags+=("--location=")
    flags+=("--notes=")
    two_word_flags+=("--notes")
    local_nonpersistent_flags+=("--notes")
    local_nonpersistent_flags+=("--notes=")
    flags+=("--remind=")
    two_word_flags+=("--remind")
    local_nonpersistent_flags+=("--remind")
    local_nonpersistent_flags+=("--remind=")
    flags+=("--repeat=")
    two_word_flags+=("--repeat")
    local_nonpersistent_flags+=("--repeat")
    local_nonpersistent_flags+=("--repeat=")
    flags+=("--repeat-times=")
    two_word_flags+=("--repeat-times")
    local_nonpersistent_flags+=("--repeat-times")
    local_nonpersistent_flags+=("--repeat-times=")
    flags+=("--repeat-until=")
    two_word_flags+=("--repeat-until")
    local_nonpersistent_flags+=("--repeat-until")
    local_nonpersistent_flags+=("--repeat-until=")
    flags+=("--start-time=")
    two_word_flags+=("--start-time")
    local_nonpersistent_flags+=("--start-time")
    local_nonpersistent_flags+=("--start-time=")
    flags+=("--starts-on=")
    two_word_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on=")
    flags+=("--time-zone=")
    two_word_flags+=("--time-zone")
    local_nonpersistent_flags+=("--time-zone")
    local_nonpersistent_flags+=("--time-zone=")
    flags+=("--title=")
    two_word_flags+=("--title")
    two_word_flags+=("-t")
    local_nonpersistent_flags+=("--title")
    local_nonpersistent_flags+=("--title=")
    local_nonpersistent_flags+=("-t")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_event_list()
{
    last_command="hey_event_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--calendar=")
    two_word_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar=")
    flags+=("--ends-on=")
    two_word_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on=")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--starts-on=")
    two_word_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_event_week()
{
    last_command="hey_event_week"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_event()
{
    last_command="hey_event"

    command_aliases=()

    commands=()
    commands+=("add")
    commands+=("day")
    commands+=("delete")
    commands+=("edit")
    commands+=("list")
    commands+=("week")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_forward()
{
    last_command="hey_forward"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--bcc=")
    two_word_flags+=("--bcc")
    local_nonpersistent_flags+=("--bcc")
    local_nonpersistent_flags+=("--bcc=")
    flags+=("--cc=")
    two_word_flags+=("--cc")
    local_nonpersistent_flags+=("--cc")
    local_nonpersistent_flags+=("--cc=")
    flags+=("--message=")
    two_word_flags+=("--message")
    two_word_flags+=("-m")
    local_nonpersistent_flags+=("--message")
    local_nonpersistent_flags+=("--message=")
    local_nonpersistent_flags+=("-m")
    flags+=("--message-html=")
    two_word_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html=")
    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_habit_complete()
{
    last_command="hey_habit_complete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--date=")
    two_word_flags+=("--date")
    local_nonpersistent_flags+=("--date")
    local_nonpersistent_flags+=("--date=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_habit_create()
{
    last_command="hey_habit_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--color=")
    two_word_flags+=("--color")
    local_nonpersistent_flags+=("--color")
    local_nonpersistent_flags+=("--color=")
    flags+=("--days=")
    two_word_flags+=("--days")
    local_nonpersistent_flags+=("--days")
    local_nonpersistent_flags+=("--days=")
    flags+=("--icon=")
    two_word_flags+=("--icon")
    local_nonpersistent_flags+=("--icon")
    local_nonpersistent_flags+=("--icon=")
    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_habit_delete()
{
    last_command="hey_habit_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_habit_edit()
{
    last_command="hey_habit_edit"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--color=")
    two_word_flags+=("--color")
    local_nonpersistent_flags+=("--color")
    local_nonpersistent_flags+=("--color=")
    flags+=("--days=")
    two_word_flags+=("--days")
    local_nonpersistent_flags+=("--days")
    local_nonpersistent_flags+=("--days=")
    flags+=("--icon=")
    two_word_flags+=("--icon")
    local_nonpersistent_flags+=("--icon")
    local_nonpersistent_flags+=("--icon=")
    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_habit_list()
{
    last_command="hey_habit_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--date=")
    two_word_flags+=("--date")
    local_nonpersistent_flags+=("--date")
    local_nonpersistent_flags+=("--date=")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_habit_uncomplete()
{
    last_command="hey_habit_uncomplete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--date=")
    two_word_flags+=("--date")
    local_nonpersistent_flags+=("--date")
    local_nonpersistent_flags+=("--date=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_habit()
{
    last_command="hey_habit"

    command_aliases=()

    commands=()
    commands+=("complete")
    commands+=("create")
    commands+=("delete")
    commands+=("edit")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("update")
        aliashash["update"]="edit"
    fi
    commands+=("list")
    commands+=("uncomplete")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_help()
{
    last_command="hey_help"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    has_completion_function=1
    noun_aliases=()
}

_hey_ignore()
{
    last_command="hey_ignore"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_journal_list()
{
    last_command="hey_journal_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--calendar=")
    two_word_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar=")
    flags+=("--ends-on=")
    two_word_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on=")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--starts-on=")
    two_word_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_journal_read()
{
    last_command="hey_journal_read"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_journal_write()
{
    last_command="hey_journal_write"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--content=")
    two_word_flags+=("--content")
    two_word_flags+=("-c")
    local_nonpersistent_flags+=("--content")
    local_nonpersistent_flags+=("--content=")
    local_nonpersistent_flags+=("-c")
    flags+=("--content-html=")
    two_word_flags+=("--content-html")
    local_nonpersistent_flags+=("--content-html")
    local_nonpersistent_flags+=("--content-html=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_journal()
{
    last_command="hey_journal"

    command_aliases=()

    commands=()
    commands+=("list")
    commands+=("read")
    commands+=("write")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_label_add()
{
    last_command="hey_label_add"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_label_create()
{
    last_command="hey_label_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_label_list()
{
    last_command="hey_label_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_label_remove()
{
    last_command="hey_label_remove"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--from=")
    two_word_flags+=("--from")
    local_nonpersistent_flags+=("--from")
    local_nonpersistent_flags+=("--from=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_label_view()
{
    last_command="hey_label_view"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_label()
{
    last_command="hey_label"

    command_aliases=()

    commands=()
    commands+=("add")
    commands+=("create")
    commands+=("list")
    commands+=("remove")
    commands+=("view")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_login()
{
    last_command="hey_login"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--cookie=")
    two_word_flags+=("--cookie")
    local_nonpersistent_flags+=("--cookie")
    local_nonpersistent_flags+=("--cookie=")
    flags+=("--no-browser")
    local_nonpersistent_flags+=("--no-browser")
    flags+=("--token=")
    two_word_flags+=("--token")
    local_nonpersistent_flags+=("--token")
    local_nonpersistent_flags+=("--token=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_logout()
{
    last_command="hey_logout"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_mcp()
{
    last_command="hey_mcp"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--domains=")
    two_word_flags+=("--domains")
    local_nonpersistent_flags+=("--domains")
    local_nonpersistent_flags+=("--domains=")
    flags+=("--read-only")
    local_nonpersistent_flags+=("--read-only")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_move()
{
    last_command="hey_move"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_reply()
{
    last_command="hey_reply"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--attach=")
    two_word_flags+=("--attach")
    local_nonpersistent_flags+=("--attach")
    local_nonpersistent_flags+=("--attach=")
    flags+=("--draft")
    local_nonpersistent_flags+=("--draft")
    flags+=("--message=")
    two_word_flags+=("--message")
    two_word_flags+=("-m")
    local_nonpersistent_flags+=("--message")
    local_nonpersistent_flags+=("--message=")
    local_nonpersistent_flags+=("-m")
    flags+=("--message-html=")
    two_word_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html")
    local_nonpersistent_flags+=("--message-html=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_screener_approve()
{
    last_command="hey_screener_approve"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--box=")
    two_word_flags+=("--box")
    local_nonpersistent_flags+=("--box")
    local_nonpersistent_flags+=("--box=")
    flags+=("--seen")
    local_nonpersistent_flags+=("--seen")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_screener_clear()
{
    last_command="hey_screener_clear"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_screener_deny()
{
    last_command="hey_screener_deny"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--spam")
    local_nonpersistent_flags+=("--spam")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_screener_history()
{
    last_command="hey_screener_history"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_screener_list()
{
    last_command="hey_screener_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_screener()
{
    last_command="hey_screener"

    command_aliases=()

    commands=()
    commands+=("approve")
    commands+=("clear")
    commands+=("deny")
    commands+=("history")
    commands+=("list")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_search_filters()
{
    last_command="hey_search_filters"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_search()
{
    last_command="hey_search"

    command_aliases=()

    commands=()
    commands+=("filters")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--any=")
    two_word_flags+=("--any")
    local_nonpersistent_flags+=("--any")
    local_nonpersistent_flags+=("--any=")
    flags+=("--attachment=")
    two_word_flags+=("--attachment")
    local_nonpersistent_flags+=("--attachment")
    local_nonpersistent_flags+=("--attachment=")
    flags+=("--date=")
    two_word_flags+=("--date")
    local_nonpersistent_flags+=("--date")
    local_nonpersistent_flags+=("--date=")
    flags+=("--exact=")
    two_word_flags+=("--exact")
    local_nonpersistent_flags+=("--exact")
    local_nonpersistent_flags+=("--exact=")
    flags+=("--from=")
    two_word_flags+=("--from")
    local_nonpersistent_flags+=("--from")
    local_nonpersistent_flags+=("--from=")
    flags+=("--in=")
    two_word_flags+=("--in")
    local_nonpersistent_flags+=("--in")
    local_nonpersistent_flags+=("--in=")
    flags+=("--label=")
    two_word_flags+=("--label")
    local_nonpersistent_flags+=("--label")
    local_nonpersistent_flags+=("--label=")
    flags+=("--none=")
    two_word_flags+=("--none")
    local_nonpersistent_flags+=("--none")
    local_nonpersistent_flags+=("--none=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--required=")
    two_word_flags+=("--required")
    local_nonpersistent_flags+=("--required")
    local_nonpersistent_flags+=("--required=")
    flags+=("--subject=")
    two_word_flags+=("--subject")
    local_nonpersistent_flags+=("--subject")
    local_nonpersistent_flags+=("--subject=")
    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_seen()
{
    last_command="hey_seen"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_group_add()
{
    last_command="hey_set-aside_group_add"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_group_create()
{
    last_command="hey_set-aside_group_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_group_delete()
{
    last_command="hey_set-aside_group_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_group_list()
{
    last_command="hey_set-aside_group_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_group_remove()
{
    last_command="hey_set-aside_group_remove"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_group_view()
{
    last_command="hey_set-aside_group_view"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_group()
{
    last_command="hey_set-aside_group"

    command_aliases=()

    commands=()
    commands+=("add")
    commands+=("create")
    commands+=("delete")
    commands+=("list")
    commands+=("remove")
    commands+=("view")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside_view()
{
    last_command="hey_set-aside_view"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--page=")
    two_word_flags+=("--page")
    local_nonpersistent_flags+=("--page")
    local_nonpersistent_flags+=("--page=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_set-aside()
{
    last_command="hey_set-aside"

    command_aliases=()

    commands=()
    commands+=("group")
    commands+=("view")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_setup_agents()
{
    last_command="hey_setup_agents"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--remove")
    local_nonpersistent_flags+=("--remove")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_setup_claude()
{
    last_command="hey_setup_claude"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_setup_codex()
{
    last_command="hey_setup_codex"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_setup_omarchy()
{
    last_command="hey_setup_omarchy"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--no-notify")
    local_nonpersistent_flags+=("--no-notify")
    flags+=("--notify")
    local_nonpersistent_flags+=("--notify")
    flags+=("--remove")
    local_nonpersistent_flags+=("--remove")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_setup()
{
    last_command="hey_setup"

    command_aliases=()

    commands=()
    commands+=("agents")
    commands+=("claude")
    commands+=("codex")
    commands+=("omarchy")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--silent-success")
    local_nonpersistent_flags+=("--silent-success")
    flags+=("--skip-agents")
    local_nonpersistent_flags+=("--skip-agents")
    flags+=("--skip-omarchy")
    local_nonpersistent_flags+=("--skip-omarchy")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_share()
{
    last_command="hey_share"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_shell-completion_generate()
{
    last_command="hey_shell-completion_generate"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--help")
    flags+=("-h")
    local_nonpersistent_flags+=("--help")
    local_nonpersistent_flags+=("-h")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    must_have_one_noun+=("bash")
    must_have_one_noun+=("fish")
    must_have_one_noun+=("powershell")
    must_have_one_noun+=("zsh")
    noun_aliases=()
}

_hey_shell-completion_install()
{
    last_command="hey_shell-completion_install"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--force")
    local_nonpersistent_flags+=("--force")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    must_have_one_noun+=("bash")
    must_have_one_noun+=("fish")
    must_have_one_noun+=("zsh")
    noun_aliases=()
}

_hey_shell-completion()
{
    last_command="hey_shell-completion"

    command_aliases=()

    commands=()
    commands+=("generate")
    commands+=("install")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_skill_install()
{
    last_command="hey_skill_install"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_skill()
{
    last_command="hey_skill"

    command_aliases=()

    commands=()
    commands+=("install")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_snippet_create()
{
    last_command="hey_snippet_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--content=")
    two_word_flags+=("--content")
    local_nonpersistent_flags+=("--content")
    local_nonpersistent_flags+=("--content=")
    flags+=("--content-html=")
    two_word_flags+=("--content-html")
    local_nonpersistent_flags+=("--content-html")
    local_nonpersistent_flags+=("--content-html=")
    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_snippet_delete()
{
    last_command="hey_snippet_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_snippet_list()
{
    last_command="hey_snippet_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_snippet_update()
{
    last_command="hey_snippet_update"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--content=")
    two_word_flags+=("--content")
    local_nonpersistent_flags+=("--content")
    local_nonpersistent_flags+=("--content=")
    flags+=("--content-html=")
    two_word_flags+=("--content-html")
    local_nonpersistent_flags+=("--content-html")
    local_nonpersistent_flags+=("--content-html=")
    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_snippet()
{
    last_command="hey_snippet"

    command_aliases=()

    commands=()
    commands+=("create")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("add")
        aliashash["add"]="create"
    fi
    commands+=("delete")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("remove")
        aliashash["remove"]="delete"
    fi
    commands+=("list")
    commands+=("update")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("edit")
        aliashash["edit"]="update"
    fi

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_spam()
{
    last_command="hey_spam"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_stop-ignoring()
{
    last_command="hey_stop-ignoring"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_thread_read()
{
    last_command="hey_thread_read"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--allow-partial")
    local_nonpersistent_flags+=("--allow-partial")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_thread()
{
    last_command="hey_thread"

    command_aliases=()

    commands=()
    commands+=("read")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_categories()
{
    last_command="hey_timetrack_categories"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_category_create()
{
    last_command="hey_timetrack_category_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_category_delete()
{
    last_command="hey_timetrack_category_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_category_rename()
{
    last_command="hey_timetrack_category_rename"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_category()
{
    last_command="hey_timetrack_category"

    command_aliases=()

    commands=()
    commands+=("create")
    commands+=("delete")
    commands+=("rename")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_current()
{
    last_command="hey_timetrack_current"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_delete()
{
    last_command="hey_timetrack_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_edit()
{
    last_command="hey_timetrack_edit"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--category=")
    two_word_flags+=("--category")
    local_nonpersistent_flags+=("--category")
    local_nonpersistent_flags+=("--category=")
    flags+=("--end=")
    two_word_flags+=("--end")
    local_nonpersistent_flags+=("--end")
    local_nonpersistent_flags+=("--end=")
    flags+=("--notes=")
    two_word_flags+=("--notes")
    local_nonpersistent_flags+=("--notes")
    local_nonpersistent_flags+=("--notes=")
    flags+=("--start=")
    two_word_flags+=("--start")
    local_nonpersistent_flags+=("--start")
    local_nonpersistent_flags+=("--start=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_export()
{
    last_command="hey_timetrack_export"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--force")
    local_nonpersistent_flags+=("--force")
    flags+=("--output=")
    two_word_flags+=("--output")
    two_word_flags+=("-o")
    local_nonpersistent_flags+=("--output")
    local_nonpersistent_flags+=("--output=")
    local_nonpersistent_flags+=("-o")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_list()
{
    last_command="hey_timetrack_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--category=")
    two_word_flags+=("--category")
    local_nonpersistent_flags+=("--category")
    local_nonpersistent_flags+=("--category=")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_start()
{
    last_command="hey_timetrack_start"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack_stop()
{
    last_command="hey_timetrack_stop"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--category=")
    two_word_flags+=("--category")
    local_nonpersistent_flags+=("--category")
    local_nonpersistent_flags+=("--category=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_timetrack()
{
    last_command="hey_timetrack"

    command_aliases=()

    commands=()
    commands+=("categories")
    commands+=("category")
    commands+=("current")
    commands+=("delete")
    commands+=("edit")
    commands+=("export")
    commands+=("list")
    commands+=("start")
    commands+=("stop")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_todo_add()
{
    last_command="hey_todo_add"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--date=")
    two_word_flags+=("--date")
    local_nonpersistent_flags+=("--date")
    local_nonpersistent_flags+=("--date=")
    flags+=("--title=")
    two_word_flags+=("--title")
    two_word_flags+=("-t")
    local_nonpersistent_flags+=("--title")
    local_nonpersistent_flags+=("--title=")
    local_nonpersistent_flags+=("-t")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_todo_complete()
{
    last_command="hey_todo_complete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_todo_delete()
{
    last_command="hey_todo_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_todo_list()
{
    last_command="hey_todo_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--calendar=")
    two_word_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar")
    local_nonpersistent_flags+=("--calendar=")
    flags+=("--ends-on=")
    two_word_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on")
    local_nonpersistent_flags+=("--ends-on=")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--starts-on=")
    two_word_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on")
    local_nonpersistent_flags+=("--starts-on=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_todo_uncomplete()
{
    last_command="hey_todo_uncomplete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_todo()
{
    last_command="hey_todo"

    command_aliases=()

    commands=()
    commands+=("add")
    commands+=("complete")
    commands+=("delete")
    commands+=("list")
    commands+=("uncomplete")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_trash()
{
    last_command="hey_trash"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_tui()
{
    last_command="hey_tui"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--remote")
    local_nonpersistent_flags+=("--remote")
    flags+=("--screener")
    local_nonpersistent_flags+=("--screener")
    flags+=("--topic=")
    two_word_flags+=("--topic")
    local_nonpersistent_flags+=("--topic")
    local_nonpersistent_flags+=("--topic=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_unseen()
{
    last_command="hey_unseen"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_unshare()
{
    last_command="hey_unshare"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_upgrade()
{
    last_command="hey_upgrade"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_version()
{
    last_command="hey_version"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_watch()
{
    last_command="hey_watch"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--box=")
    two_word_flags+=("--box")
    local_nonpersistent_flags+=("--box")
    local_nonpersistent_flags+=("--box=")
    flags+=("--events=")
    two_word_flags+=("--events")
    local_nonpersistent_flags+=("--events")
    local_nonpersistent_flags+=("--events=")
    flags+=("--exit-on-first")
    local_nonpersistent_flags+=("--exit-on-first")
    flags+=("--run-async=")
    two_word_flags+=("--run-async")
    local_nonpersistent_flags+=("--run-async")
    local_nonpersistent_flags+=("--run-async=")
    flags+=("--run-sync=")
    two_word_flags+=("--run-sync")
    local_nonpersistent_flags+=("--run-sync")
    local_nonpersistent_flags+=("--run-sync=")
    flags+=("--since=")
    two_word_flags+=("--since")
    local_nonpersistent_flags+=("--since")
    local_nonpersistent_flags+=("--since=")
    flags+=("--timeout=")
    two_word_flags+=("--timeout")
    local_nonpersistent_flags+=("--timeout")
    local_nonpersistent_flags+=("--timeout=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_add()
{
    last_command="hey_workflow_add"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--stage=")
    two_word_flags+=("--stage")
    local_nonpersistent_flags+=("--stage")
    local_nonpersistent_flags+=("--stage=")
    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_create()
{
    last_command="hey_workflow_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_delete()
{
    last_command="hey_workflow_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_list()
{
    last_command="hey_workflow_list"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--all")
    local_nonpersistent_flags+=("--all")
    flags+=("--limit=")
    two_word_flags+=("--limit")
    local_nonpersistent_flags+=("--limit")
    local_nonpersistent_flags+=("--limit=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_move()
{
    last_command="hey_workflow_move"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--to=")
    two_word_flags+=("--to")
    local_nonpersistent_flags+=("--to")
    local_nonpersistent_flags+=("--to=")
    flags+=("--workflow=")
    two_word_flags+=("--workflow")
    local_nonpersistent_flags+=("--workflow")
    local_nonpersistent_flags+=("--workflow=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_remove()
{
    last_command="hey_workflow_remove"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--from=")
    two_word_flags+=("--from")
    local_nonpersistent_flags+=("--from")
    local_nonpersistent_flags+=("--from=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_stage_create()
{
    last_command="hey_workflow_stage_create"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_stage_delete()
{
    last_command="hey_workflow_stage_delete"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_stage_update()
{
    last_command="hey_workflow_stage_update"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_stage()
{
    last_command="hey_workflow_stage"

    command_aliases=()

    commands=()
    commands+=("create")
    commands+=("delete")
    commands+=("update")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("edit")
        aliashash["edit"]="update"
        command_aliases+=("rename")
        aliashash["rename"]="update"
    fi

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_update()
{
    last_command="hey_workflow_update"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--name=")
    two_word_flags+=("--name")
    local_nonpersistent_flags+=("--name")
    local_nonpersistent_flags+=("--name=")
    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow_view()
{
    last_command="hey_workflow_view"

    command_aliases=()

    commands=()

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_workflow()
{
    last_command="hey_workflow"

    command_aliases=()

    commands=()
    commands+=("add")
    commands+=("create")
    commands+=("delete")
    commands+=("list")
    commands+=("move")
    commands+=("remove")
    commands+=("stage")
    commands+=("update")
    if [[ -z "${BASH_VERSION:-}" || "${BASH_VERSINFO[0]:-}" -gt 3 ]]; then
        command_aliases+=("edit")
        aliashash["edit"]="update"
        command_aliases+=("rename")
        aliashash["rename"]="update"
    fi
    commands+=("view")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

_hey_root_command()
{
    last_command="hey"

    command_aliases=()

    commands=()
    commands+=("account")
    commands+=("attachment")
    commands+=("auth")
    commands+=("box")
    commands+=("bubble")
    commands+=("bulk-reply")
    commands+=("bundle")
    commands+=("calendar")
    commands+=("clip")
    commands+=("collection")
    commands+=("commands")
    commands+=("compose")
    commands+=("config")
    commands+=("contact")
    commands+=("doctor")
    commands+=("draft")
    commands+=("event")
    commands+=("forward")
    commands+=("habit")
    commands+=("help")
    commands+=("ignore")
    commands+=("journal")
    commands+=("label")
    commands+=("login")
    commands+=("logout")
    commands+=("mcp")
    commands+=("move")
    commands+=("reply")
    commands+=("screener")
    commands+=("search")
    commands+=("seen")
    commands+=("set-aside")
    commands+=("setup")
    commands+=("share")
    commands+=("shell-completion")
    commands+=("skill")
    commands+=("snippet")
    commands+=("spam")
    commands+=("stop-ignoring")
    commands+=("thread")
    commands+=("timetrack")
    commands+=("todo")
    commands+=("trash")
    commands+=("tui")
    commands+=("unseen")
    commands+=("unshare")
    commands+=("upgrade")
    commands+=("version")
    commands+=("watch")
    commands+=("workflow")

    flags=()
    two_word_flags=()
    local_nonpersistent_flags=()
    flags_with_completion=()
    flags_completion=()

    flags+=("--account=")
    two_word_flags+=("--account")
    flags+=("--base-url=")
    two_word_flags+=("--base-url")
    flags+=("--count")
    flags+=("--html")
    flags+=("--ids-only")
    flags+=("--jq=")
    two_word_flags+=("--jq")
    flags+=("--json")
    flags+=("--markdown")
    flags+=("--quiet")
    flags+=("--stats")
    flags+=("--styled")
    flags+=("--verbose")
    flags+=("-v")
    flags+=("--version")
    local_nonpersistent_flags+=("--version")

    must_have_one_flag=()
    must_have_one_noun=()
    noun_aliases=()
}

__start_hey()
{
    local cur prev words cword split
    declare -A flaghash 2>/dev/null || :
    declare -A aliashash 2>/dev/null || :
    if declare -F _init_completion >/dev/null 2>&1; then
        _init_completion -s || return
    else
        __hey_init_completion -n "=" || return
    fi

    local c=0
    local flag_parsing_disabled=
    local flags=()
    local two_word_flags=()
    local local_nonpersistent_flags=()
    local flags_with_completion=()
    local flags_completion=()
    local commands=("hey")
    local command_aliases=()
    local must_have_one_flag=()
    local must_have_one_noun=()
    local has_completion_function=""
    local last_command=""
    local nouns=()
    local noun_aliases=()

    __hey_handle_word
}

if [[ $(type -t compopt) = "builtin" ]]; then
    complete -o default -F __start_hey hey
else
    complete -o default -o nospace -F __start_hey hey
fi

# ex: ts=4 sw=4 et filetype=sh
